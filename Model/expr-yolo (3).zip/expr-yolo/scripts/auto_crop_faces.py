import os, sys, glob, cv2
from ultralytics import YOLO


src_dir = sys.argv[1]
out_root = sys.argv[2]
fps_keep = float(sys.argv[3])
conf_th = float(sys.argv[4]) if len(sys.argv) > 4 else 0.15 

face_model_path = "yolov8n-face.pt"
if not os.path.isfile(face_model_path):
    raise FileNotFoundError(
        "yolov8n-face.pt tidak ditemukan. Unduh dulu dan letakkan di root project."
    )

classes = ["happy","sad","angry","surprised","scared"]
segment_seconds = 10.0
tmp_root = os.path.join(out_root, "_tmp")
for c in classes:
    os.makedirs(os.path.join(tmp_root, c), exist_ok=True)

face_model = YOLO(face_model_path)
images = sorted(glob.glob(os.path.join(src_dir, "*.jpg")))
saved_per_class = {k:0 for k in classes}

def idx_to_class(idx: int) -> str:
    t = idx / fps_keep
    seg = int(t // segment_seconds)
    if seg < 0: seg = 0
    if seg > 4: seg = 4
    return classes[seg]

for i, p in enumerate(images):
    img = cv2.imread(p)
    if img is None:
        continue

    res = face_model.predict(source=img, imgsz=640, conf=conf_th, verbose=False)
    boxes = []
    for r in res:
        if r.boxes is None: 
            continue
        for b in r.boxes:
            x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
            h, w = img.shape[:2]
            dx = int(0.10 * (x2-x1)); dy = int(0.10 * (y2-y1))
            x1 = max(0, x1 - dx); y1 = max(0, y1 - dy)
            x2 = min(w, x2 + dx); y2 = min(h, y2 + dy)
            if x2 > x1 and y2 > y1:
                boxes.append((x1,y1,x2,y2))

    if not boxes:
        continue

    label = idx_to_class(i)
    out_dir = os.path.join(tmp_root, label)

    for k, (x1,y1,x2,y2) in enumerate(boxes):
        crop = img[y1:y2, x1:x2]
        if crop.size == 0:
            continue
        crop = cv2.resize(crop, (224,224), interpolation=cv2.INTER_LINEAR)
        fname = f"{os.path.basename(src_dir)}_{i:06d}_{k}.jpg"
        cv2.imwrite(os.path.join(out_dir, fname), crop)
        saved_per_class[label] += 1

print("Selesai crop (YOLO-only) ke:", tmp_root)
for c in classes:
    print(f"{c}: {saved_per_class[c]}")
