# scripts/realtime.py
import sys, time, os
import cv2
import torch
from ultralytics import YOLO

cls_w = sys.argv[1]
cam_index = int(sys.argv[2]) if len(sys.argv) > 2 else 0
DET_CONF = float(sys.argv[3]) if len(sys.argv) > 3 else 0.25
CLS_IMGSZ = int(sys.argv[4]) if len(sys.argv) > 4 else 224

FACE_W = "yolov8n-face.pt"
if not os.path.isfile(FACE_W):
    raise FileNotFoundError(
        "File 'yolov8n-face.pt' tidak ditemukan di root project. "
        "Unduh dulu (sudah kamu punya ~6.3MB)."
    )

device = 0 if torch.cuda.is_available() else None
face_model = YOLO(FACE_W)
cls_model  = YOLO(cls_w)
names = cls_model.names  

cap = cv2.VideoCapture(cam_index)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,  960)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)

prev_t = time.time()

def expand_box(x1,y1,x2,y2,w,h,ratio=0.10):
    dx = int(ratio*(x2-x1)); dy = int(ratio*(y2-y1))
    x1 = max(0, x1-dx); y1 = max(0, y1-dy)
    x2 = min(w, x2+dx); y2 = min(h, y2+dy)
    return x1,y1,x2,y2

while True:
    ok, frame = cap.read()
    if not ok:
        break
    H, W = frame.shape[:2]

    det = face_model.predict(
        source=frame, imgsz=640, conf=DET_CONF, verbose=False, device=device
    )
    boxes = []
    for r in det:
        if r.boxes is None: continue
        for b in r.boxes:
            x1,y1,x2,y2 = map(int, b.xyxy[0].tolist())
            x1,y1,x2,y2 = expand_box(x1,y1,x2,y2,W,H,ratio=0.10)
            if x2>x1 and y2>y1:
                boxes.append((x1,y1,x2,y2))

    labels = []
    if boxes:
        crops = []
        for (x1,y1,x2,y2) in boxes:
            crop = frame[y1:y2, x1:x2]
            if crop.size == 0:
                crops.append(None)
            else:
                crops.append(cv2.resize(crop, (CLS_IMGSZ, CLS_IMGSZ), interpolation=cv2.INTER_LINEAR))

        batch = [c for c in crops if c is not None]
        preds = []
        if batch:
            res = cls_model.predict(source=batch, imgsz=CLS_IMGSZ, verbose=False, device=device)
            for rr in res:
                p = rr.probs
                idx = int(p.top1)
                conf = float(p.top1conf)
                preds.append((names[idx], conf))

        j = 0
        for c in crops:
            if c is None:
                labels.append(("unknown", 0.0))
            else:
                labels.append(preds[j]); j+=1

    for (x1,y1,x2,y2),(lab,conf) in zip(boxes, labels):
        cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0),2)
        cv2.putText(frame, f"{lab} {conf:.2f}", (x1, max(0,y1-8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

    now = time.time()
    fps = 1.0/(now-prev_t) if now>prev_t else 0.0
    prev_t = now
    cv2.putText(frame, f"FPS: {fps:.1f}", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)

    cv2.imshow("Realtime Expression (YOLOv8)", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
