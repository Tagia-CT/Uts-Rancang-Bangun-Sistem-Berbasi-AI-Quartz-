import os, random, shutil, glob, sys

root = sys.argv[1]                    
val_ratio = float(sys.argv[2]) if len(sys.argv) > 2 else 0.2

tmp = os.path.join(root, "_tmp")      
train_dir = os.path.join(root, "train")
val_dir = os.path.join(root, "val")

assert os.path.isdir(tmp), "Run auto_crop_faces.py dulu."

for c in os.listdir(tmp):
    src = os.path.join(tmp, c)
    if not os.path.isdir(src):
        continue

    imgs = glob.glob(os.path.join(src, "*.jpg"))
    random.shuffle(imgs)
    n_val = int(len(imgs) * val_ratio)

    os.makedirs(os.path.join(train_dir, c), exist_ok=True)
    os.makedirs(os.path.join(val_dir, c), exist_ok=True)

    for i, p in enumerate(imgs):
        dst_root = val_dir if i < n_val else train_dir
        shutil.copy(p, os.path.join(dst_root, c, os.path.basename(p)))

print("Split done.")
