import cv2, os, sys



video = sys.argv[1]                          
outdir = sys.argv[2]                        
fps_keep = float(sys.argv[3]) if len(sys.argv) > 3 else 5.0

os.makedirs(outdir, exist_ok=True)

cap = cv2.VideoCapture(video)
if not cap.isOpened():
    raise RuntimeError(f"Tidak bisa membuka video: {video}")

src_fps = cap.get(cv2.CAP_PROP_FPS) or 30
step = max(int(round(src_fps / fps_keep)), 1)

i = 0
saved = 0
while True:
    ok, frame = cap.read()
    if not ok:
        break
    if i % step == 0:
        cv2.imwrite(os.path.join(outdir, f"f_{saved:06d}.jpg"), frame)
        saved += 1
    i += 1

cap.release()
print(f"FPS sumber ~{src_fps:.2f}, simpan tiap {step} frame -> {saved} gambar di {outdir}")
