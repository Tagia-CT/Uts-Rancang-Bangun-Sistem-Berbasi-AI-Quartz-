from ultralytics import YOLO

model = YOLO("yolov8n-cls.pt")

model.train(
    data="dataset/faces_cls_dataset",  
    epochs=60,
    imgsz=224,
    batch=8,               
    device=0,              
    workers=0,             
    pin_memory=False,      
    persistent_workers=False,
    patience=10
)